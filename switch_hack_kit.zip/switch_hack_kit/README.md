# Operation: Switch Breach 🎮

A fake, totally-local "hacking" game for teaching Python. Nothing here touches
a real console — it's two programs on the same computer talking through a
shared `state.json` file, made to feel like a live hack.

## Files

| File | What it is |
|---|---|
| `switch_ui.html` | The fake console screen — this is what the kid watches |
| `switch_link.py` | Pre-built "connection" library (don't edit) — the kid imports this |
| `fake_game_cartridge.py` | A fake game's data — the kid can customize it |
| `hack_challenge.py` | **The kid's file.** Has the mission + TODOs to fill in |
| `state.json` | Shared scratchpad the two programs use to talk. Auto-created/updated. |

## How to run it

Because browsers block a webpage from reading local files directly, you need
a tiny local web server (built into Python already — no install needed).

1. Open a terminal in this folder.
2. Start a local server:
   ```
   python -m http.server 8000
   ```
3. Open your browser to: **http://localhost:8000/switch_ui.html**
   — leave this tab open.
4. In a **second terminal**, in the same folder, run:
   ```
   python hack_challenge.py
   ```
5. Watch the console screen react live as the code runs!

Every time the kid edits `hack_challenge.py` and reruns it, the screen updates.
Run `python -c "import switch_link; switch_link.reset()"` any time to reset the
console back to locked.

## The mission, stage by stage

1. **Connect** — already written, just to show the "hacker terminal" vibe.
2. **Crack the PIN** — kid writes a `for` loop trying every 4-digit code
   against `switch.try_pin(pin)`. Great intro to loops + string formatting.
3. **Decode the key** — a Caesar-cipher puzzle (shift-3). Great intro to
   `ord()`/`chr()` and modular arithmetic, or just a lookup table for younger
   kids.
4. **Install the game** — load `fake_game_cartridge.py` and call
   `switch.install_game(cartridge)`. Great intro to importing your own
   modules and working with dictionaries.

## Ideas to extend it

- Have the kid invent their own cartridge (title/icon/genre) in
  `fake_game_cartridge.py` and reinstall it.
- Change `_SECRET_PIN` in `switch_link.py` to a new number as a "harder
  difficulty" round.
- Ask the kid to add a `print()` play-by-play of their loop's guesses to see
  brute force in action before optimizing it.
