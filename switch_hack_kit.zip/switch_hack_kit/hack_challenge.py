"""
====================================
  OPERATION: SWITCH BREACH
  Your mission, should you choose to accept it...
====================================

Run this file with:  python hack_challenge.py

Keep switch_ui.html open in your browser while you run it, and watch
the console screen react to your code LIVE!
"""

import switch_link as switch


# -------------------------------------------------
# STEP 1: Connect to the console
# -------------------------------------------------
switch.connect()


# -------------------------------------------------
# STEP 2: Crack the 4-digit PIN lock
#
# The PIN is a mystery number between 0000 and 9999.
# TODO: Write a loop that tries every possible PIN using
#       switch.try_pin(pin) until it returns True.
#
# Hint: pin needs to be a 4-character string, like "0007",
#       not just the number 7.
# -------------------------------------------------
print("Cracking the PIN...")

found_pin = None
# for guess in range(10000):
#     pin = f"{guess:04d}"
#     if switch.try_pin(pin):
#         found_pin = pin
#         break

print(f"PIN cracked: {found_pin}")


# -------------------------------------------------
# STEP 3: Decode the security key
#
# The firewall gives you a scrambled key. It was encoded with a
# "Caesar cipher" — every letter was shifted forward by 3 in the
# alphabet (A -> D, B -> E, C -> F, ...).
#
# TODO: Decode encrypted_key by shifting each letter BACK by 3,
#       then submit it with switch.submit_key(decoded_key).
# -------------------------------------------------
encrypted_key = switch.get_encrypted_key()
print(f"Encrypted key from firewall: {encrypted_key}")

decoded_key = ""
# TODO: build decoded_key here
# for letter in encrypted_key:
#     shifted = chr((ord(letter) - ord('A') - 3) % 26 + ord('A'))
#     decoded_key += shifted

switch.submit_key(decoded_key)


# -------------------------------------------------
# STEP 4: Install a game onto the unlocked console
# -------------------------------------------------
import fake_game_cartridge

cartridge = fake_game_cartridge.get_cartridge()
switch.install_game(cartridge)

print("Mission status: check the console screen!")
