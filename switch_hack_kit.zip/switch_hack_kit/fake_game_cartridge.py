"""
fake_game_cartridge.py
========================
This is a pretend "game cartridge" — just data describing a made-up game.
In the final step of the mission, you'll load this file and install the
game onto the console.

Try changing the title, icon, or description and re-running your mission
to see YOUR custom game show up on the fake home screen!
"""

def get_cartridge():
    return {
        "title": "Mystery Quest",
        "icon": "🗺️",
        "size_mb": 3200,
        "genre": "Adventure",
        "description": "A hand-crafted cartridge, freshly installed by a top-secret agent.",
    }
