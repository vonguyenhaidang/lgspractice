"""
switch_link.py
================
This is the "pre-wired" connection between your Python code and the
fake console on screen (switch_ui.html). You don't need to edit this
file — just import it and call its functions from hack_challenge.py.

HOW IT WORKS (fun fact for curious kids):
Every function here writes a small update into state.json. The webpage
checks that file a few times a second and redraws itself. That's the
whole "hack" — it's just two programs talking through a shared notebook!
"""

import json
import os
import time
import random

STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "state.json")

# The secret PIN the console is locked with. In a real device this would
# be unknown — here we hide it in this file so a for-loop can "discover" it.
_SECRET_PIN = "7429"

# The encrypted access key guarding the firewall (Caesar cipher, shift 3)
_ENCRYPTED_KEY = "DFFHVVJUDQWHG"   # decodes to ACCESSGRANTED
_REAL_KEY = "ACCESSGRANTED"


def _default_state():
    return {
        "status": "offline",       # offline -> connecting -> locked -> pin_cracked -> unlocked -> game_installed
        "log": [],
        "pin_attempts": 0,
        "progress": 0,
        "installed_games": [],
    }


def _load():
    if not os.path.exists(STATE_FILE):
        return _default_state()
    try:
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError):
        return _default_state()


def _save(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def _log(state, message):
    state["log"].append(message)
    state["log"] = state["log"][-40:]  # keep it from growing forever


def reset():
    """Wipe the console back to its locked, offline state. Handy to re-run the mission."""
    _save(_default_state())
    print("🔌 Console reset. Run connect() to begin.")


def connect():
    """Step 1: Establish a connection to the console."""
    state = _load()
    state["status"] = "connecting"
    _log(state, "📡 Searching for nearby console...")
    _save(state)
    time.sleep(0.6)

    state = _load()
    state["status"] = "locked"
    state["progress"] = 10
    _log(state, "✅ Console found! It's PIN-locked.")
    _save(state)
    print("Connected. The console is locked with a 4-digit PIN. Try try_pin('0000') style guesses!")


def try_pin(pin):
    """
    Step 2: Try a 4-digit PIN (as a string, e.g. '0428').
    Returns True if correct, False otherwise.
    """
    state = _load()
    state["pin_attempts"] += 1
    correct = str(pin) == _SECRET_PIN

    if correct:
        state["status"] = "pin_cracked"
        state["progress"] = 45
        _log(state, f"🔓 PIN {pin} accepted! Lock disengaged.")
    else:
        # Only log occasionally so the terminal doesn't get too spammy during a brute force
        if state["pin_attempts"] % 500 == 0 or state["pin_attempts"] < 5:
            _log(state, f"❌ PIN {pin} rejected. ({state['pin_attempts']} attempts so far)")
        state["progress"] = min(40, state["progress"] + 0.02)

    _save(state)
    return correct


def get_encrypted_key():
    """Step 3: Returns the scrambled security key you need to decode."""
    state = _load()
    _log(state, "🧩 Firewall requests security key: " + _ENCRYPTED_KEY)
    _save(state)
    return _ENCRYPTED_KEY


def submit_key(decoded_key):
    """Step 3b: Submit your decoded key. Returns True if the firewall opens."""
    state = _load()
    correct = decoded_key.strip().upper() == _REAL_KEY

    if correct:
        state["status"] = "unlocked"
        state["progress"] = 80
        _log(state, "🛡️ Firewall bypassed! Console fully unlocked.")
    else:
        _log(state, f"❌ Key '{decoded_key}' rejected by firewall.")

    _save(state)
    return correct


def install_game(cartridge):
    """
    Step 4: Install a fake game cartridge (a dict from fake_game_cartridge.py)
    onto the console's home screen.
    """
    state = _load()
    if state["status"] not in ("unlocked", "game_installed"):
        print("⚠️  The console is still locked — finish unlocking it first!")
        return False

    state["installed_games"].append(cartridge)
    state["status"] = "game_installed"
    state["progress"] = 100
    _log(state, f"🎮 Installed '{cartridge.get('title', 'Unknown Game')}'!")
    _save(state)
    print(f"Installed {cartridge.get('title')} — check the console screen!")
    return True
