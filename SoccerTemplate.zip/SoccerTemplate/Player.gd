extends KinematicBody2D

# ------------------------------------------------------------------
# TWEAKABLE SETTINGS
# ------------------------------------------------------------------
export var speed = 250.0
export var kick_force = 700.0

var facing = Vector2.DOWN   # Direction the player last moved/kicked toward
var ball_in_range = null    # Set when the ball enters the KickArea


func _physics_process(delta):
	# --- Read input (4-directional, no gravity) ---
	var input_vec = Vector2.ZERO
	if Input.is_action_pressed("ui_right"):
		input_vec.x += 1
	if Input.is_action_pressed("ui_left"):
		input_vec.x -= 1
	if Input.is_action_pressed("ui_down"):
		input_vec.y += 1
	if Input.is_action_pressed("ui_up"):
		input_vec.y -= 1

	if input_vec.length() > 0:
		input_vec = input_vec.normalized()
		facing = input_vec

	move_and_slide(input_vec * speed)

	# --- Kick the ball if it's close enough ---
	if ball_in_range != null and Input.is_action_just_pressed("ui_accept"):
		ball_in_range.kick(facing, kick_force)


func _on_KickArea_body_entered(body):
	if body.is_in_group("ball"):
		ball_in_range = body


func _on_KickArea_body_exited(body):
	if body.is_in_group("ball"):
		ball_in_range = null


# ------------------------------------------------------------------
# TO REPLACE THE PLACEHOLDER CHARACTER:
# 1. Import your own sprite into the project.
# 2. Open Player.tscn, select the "Sprite" node, set its Texture.
# 3. For animated sprites, swap "Sprite" for an AnimatedSprite node
#    and play animations here, e.g. $AnimatedSprite.play("run").
# ------------------------------------------------------------------
