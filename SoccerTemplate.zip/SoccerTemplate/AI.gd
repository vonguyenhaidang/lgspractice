extends KinematicBody2D

# ------------------------------------------------------------------
# TWEAKABLE SETTINGS
# ------------------------------------------------------------------
export var speed = 200.0
export var kick_force = 650.0
export var kick_range = 40.0
export var kick_cooldown = 0.8
export var target_goal_x = 0.0   # x position of the goal the AI shoots at

var ball = null
var cooldown_timer = 0.0


func _ready():
	# Find the ball anywhere in the scene by group, so this works
	# regardless of where AI.tscn is placed in the tree.
	var balls = get_tree().get_nodes_in_group("ball")
	if balls.size() > 0:
		ball = balls[0]


func _physics_process(delta):
	if cooldown_timer > 0:
		cooldown_timer -= delta

	if ball == null:
		return

	var to_ball = ball.global_position - global_position
	var distance = to_ball.length()

	if distance > kick_range:
		# --- Chase the ball ---
		move_and_slide(to_ball.normalized() * speed)
	elif cooldown_timer <= 0:
		# --- Close enough: kick it toward the target goal ---
		var goal_pos = Vector2(target_goal_x, ball.global_position.y)
		var kick_dir = (goal_pos - ball.global_position).normalized()
		ball.kick(kick_dir, kick_force)
		cooldown_timer = kick_cooldown


# ------------------------------------------------------------------
# MAKING THE AI SMARTER (ideas for the student to try):
# - Add a "home area" so the AI doesn't chase the ball the whole field.
# - Aim kicks away from the player instead of straight at the goal center.
# - Give the AI a reaction delay so it isn't perfectly responsive.
# ------------------------------------------------------------------
