extends KinematicBody2D

# ------------------------------------------------------------------
# TWEAKABLE SETTINGS
# ------------------------------------------------------------------
export var friction = 400.0    # How quickly the ball slows down
export var max_speed = 900.0   # Speed cap so kicks can't get out of hand
export var bounciness = 0.6    # 0 = stops dead off walls, 1 = perfect bounce

var velocity = Vector2.ZERO


func kick(direction, force):
	velocity = direction.normalized() * force
	if velocity.length() > max_speed:
		velocity = velocity.normalized() * max_speed


func reset(new_position):
	position = new_position
	velocity = Vector2.ZERO


func _physics_process(delta):
	# --- Friction: slow the ball down over time ---
	if velocity.length() > 0:
		var slowdown = velocity.normalized() * friction * delta
		if slowdown.length() > velocity.length():
			velocity = Vector2.ZERO
		else:
			velocity -= slowdown

	# --- Move and bounce off anything solid (walls) ---
	var collision = move_and_collide(velocity * delta)
	if collision:
		velocity = velocity.bounce(collision.normal) * bounciness
