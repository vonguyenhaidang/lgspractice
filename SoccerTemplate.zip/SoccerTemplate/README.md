# 2D Soccer Template — Player vs AI (Godot 3.x)

A minimal top-down soccer starter. Open the folder in Godot 3.x
(File > Open Project, select this folder) and press Play.

## What's included

| File | Purpose |
|---|---|
| `Main.tscn` / `Main.gd` | The field: background, walls, both goals, scoring logic. |
| `Player.tscn` / `Player.gd` | The character you control: 4-directional movement + kicking. |
| `AI.tscn` / `AI.gd` | The opponent: chases the ball and kicks it toward your goal. |
| `Ball.tscn` / `Ball.gd` | Ball physics: friction, wall bounces, and the `kick()` function. |
| `assets/field_bg.png` | Placeholder pitch graphic (lines, center circle). |
| `assets/player.png` | Placeholder blue player sprite — swap this out! |
| `assets/ai.png` | Placeholder red AI sprite. |
| `assets/ball.png` | Placeholder ball sprite. |

## Controls (already wired up)

- **Arrow keys** — move in any of the 4 directions
- **Space or Enter** — kick the ball, if it's close enough

These use Godot's built-in `ui_left/right/up/down` and `ui_accept` actions,
so nothing needs configuring in Project Settings.

## How the game works

- The **Player** starts on the left, the **AI** starts on the right.
- Get near the ball and press kick to send it flying in the direction
  you're facing.
- The **AI** always chases the ball and, once close enough, kicks it toward
  the goal on the **left** (your goal) — so it's actually trying to score
  on you.
- Whichever edge of the field the ball crosses counts as a goal for the
  opposite side. The score resets both players and the ball to their
  starting positions after every goal.

## Adding your own character

1. Import your sprite image(s) into the project.
2. Open `Player.tscn`, select the **Sprite** node, set its **Texture**.
3. For an animated character, swap **Sprite** for an **AnimatedSprite**
   node and build a `SpriteFrames` resource, then play animations from
   `Player.gd` (e.g. `$AnimatedSprite.play("run")`).
4. If the new sprite has a different size, adjust `CollisionShape2D`
   under Player so its hitbox still matches the character.
5. Do the same for `AI.tscn` if you want the opponent to look different too.

## Tweaking the feel

Select **Player** or **AI** in their scenes and adjust exported values in
the Inspector — no code changes needed:

- `speed` — movement speed
- `kick_force` — how hard the ball is kicked
- (Player only) the kick range is set by the `KickShape` collision radius
  under `KickArea`
- (AI only) `kick_range`, `kick_cooldown`, `target_goal_x`

On the **Ball** node: `friction`, `max_speed`, and `bounciness` control
how the ball rolls and bounces off walls.

## Ideas to extend this template

- Add a proper goal *mouth* instead of a full-width goal line (narrow the
  `GoalLeft`/`GoalRight` Area2D shapes and add solid wall segments beside them).
- Add a second AI teammate, or make the AI defend as well as attack.
- Add a match timer and a "Game Over" screen.
- Replace the placeholder art with sprite sheets and animations
  (idle, run, kick).

Have fun!
