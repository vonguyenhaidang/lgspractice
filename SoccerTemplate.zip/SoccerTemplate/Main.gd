extends Node2D

var score_player = 0
var score_ai = 0

onready var ball = $Ball
onready var player = $Player
onready var ai = $AI
onready var score_label = $ScoreLabel

var ball_start_pos
var player_start_pos
var ai_start_pos


func _ready():
	ball_start_pos = ball.position
	player_start_pos = player.position
	ai_start_pos = ai.position
	update_score_label()


func _on_GoalLeft_body_entered(body):
	# Ball entering the LEFT goal means the AI scored (Player defends left)
	if body == ball:
		score_ai += 1
		goal_scored()


func _on_GoalRight_body_entered(body):
	# Ball entering the RIGHT goal means the Player scored (AI defends right)
	if body == ball:
		score_player += 1
		goal_scored()


func goal_scored():
	update_score_label()
	ball.reset(ball_start_pos)
	player.position = player_start_pos
	ai.position = ai_start_pos


func update_score_label():
	score_label.text = "Player %d  -  %d AI" % [score_player, score_ai]
