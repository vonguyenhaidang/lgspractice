import tkinter as tk
from tkinter import ttk
from tkinter import messagebox


class StudentView:

    def __init__(self, root):
        self.root = root
        self.root.title("Student Management System")
        self.root.geometry("850x650")

        self.build_form()
        self.build_buttons()
        self.build_search()
        self.build_table()

    def build_form(self):
        form_frame = tk.Frame(self.root, padx=20, pady=20)
        form_frame.pack(fill="x")

        tk.Label(form_frame, text="Student ID").grid(row=0, column=0, sticky="w")
        self.entry_id = tk.Entry(form_frame, width=25)
        self.entry_id.grid(row=0, column=1, padx=10, pady=5)

        tk.Label(form_frame, text="Name").grid(row=1, column=0, sticky="w")
        self.entry_name = tk.Entry(form_frame, width=25)
        self.entry_name.grid(row=1, column=1, padx=10, pady=5)

        tk.Label(form_frame, text="Age").grid(row=2, column=0, sticky="w")
        self.entry_age = tk.Entry(form_frame, width=25)
        self.entry_age.grid(row=2, column=1, padx=10, pady=5)

        tk.Label(form_frame, text="Grade").grid(row=3, column=0, sticky="w")
        self.entry_grade = tk.Entry(form_frame, width=25)
        self.entry_grade.grid(row=3, column=1, padx=10, pady=5)

    def build_buttons(self):
        button_frame = tk.Frame(self.root, padx=20, pady=10)
        button_frame.pack(fill="x")

        self.btn_add = tk.Button(button_frame, text="Add", width=12)
        self.btn_add.grid(row=0, column=0, padx=5)

        self.btn_update = tk.Button(button_frame, text="Update", width=12)
        self.btn_update.grid(row=0, column=1, padx=5)

        self.btn_delete = tk.Button(button_frame, text="Delete", width=12)
        self.btn_delete.grid(row=0, column=2, padx=5)

        self.btn_clear = tk.Button(button_frame, text="Clear", width=12)
        self.btn_clear.grid(row=0, column=3, padx=5)

    def build_search(self):
        search_frame = tk.Frame(self.root, padx=20, pady=10)
        search_frame.pack(fill="x")

        tk.Label(search_frame, text="Search").pack(side="left")

        self.entry_search = tk.Entry(search_frame, width=30)
        self.entry_search.pack(side="left", padx=10)

        self.btn_search = tk.Button(search_frame, text="Search", width=10)
        self.btn_search.pack(side="left", padx=5)

        self.btn_clear_search = tk.Button(search_frame, text="Clear Search", width=12)
        self.btn_clear_search.pack(side="left", padx=5)

    def build_table(self):
        table_frame = tk.Frame(self.root, padx=20, pady=10)
        table_frame.pack(fill="both", expand=True)

        columns = ("student_id", "name", "age", "grade")

        self.tree = ttk.Treeview(
            table_frame,
            columns=columns,
            show="headings",
            height=12
        )

        self.tree.heading("student_id", text="Student ID")
        self.tree.heading("name", text="Name")
        self.tree.heading("age", text="Age")
        self.tree.heading("grade", text="Grade")

        self.tree.column("student_id", width=100)
        self.tree.column("name", width=200)
        self.tree.column("age", width=80)
        self.tree.column("grade", width=150)

        self.tree.pack(fill="both", expand=True)

    def get_form_data(self):
        return (
            self.entry_id.get().strip(),
            self.entry_name.get().strip(),
            self.entry_age.get().strip(),
            self.entry_grade.get().strip()
        )

    def clear_form(self):
        self.entry_id.delete(0, tk.END)
        self.entry_name.delete(0, tk.END)
        self.entry_age.delete(0, tk.END)
        self.entry_grade.delete(0, tk.END)

    def fill_form(self, student_id, name, age, grade):
        self.clear_form()
        self.entry_id.insert(0, student_id)
        self.entry_name.insert(0, name)
        self.entry_age.insert(0, age)
        self.entry_grade.insert(0, grade)

    def clear_table(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

    def insert_row(self, student_id, name, age, grade):
        self.tree.insert("", tk.END, values=(student_id, name, age, grade))

    def get_selected_item(self):
        return self.tree.selection()

    def get_row_values(self, item):
        return self.tree.item(item, "values")

    def show_message(self, title, message):
        messagebox.showinfo(title, message)

    def show_error(self, title, message):
        messagebox.showerror(title, message)

    def ask_confirmation(self, title, message):
        return messagebox.askyesno(title, message)
