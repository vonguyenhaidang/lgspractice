from models.student import Student
from models.student_manager import StudentManager


class StudentController:

    def __init__(self, view):
        self.view = view
        self.manager = StudentManager()

        self.view.btn_add.config(command=self.add_student)
        self.view.btn_update.config(command=self.update_student)
        self.view.btn_delete.config(command=self.delete_student)
        self.view.btn_clear.config(command=self.clear_form)
        self.view.btn_search.config(command=self.search_student)
        self.view.btn_clear_search.config(command=self.clear_search)

        self.view.tree.bind("<<TreeviewSelect>>", self.select_student)

        self.load_sample_data()

    def load_sample_data(self):
        sample_students = [
            Student("S001", "Nguyen Van An", 15, "Grade 9"),
            Student("S002", "Tran Minh Anh", 16, "Grade 10"),
            Student("S003", "Le Hoang Nam", 17, "Grade 11"),
        ]
        for student in sample_students:
            self.manager.add_student(student)
        self.refresh_table()

    def validate_input(self, student_id, name, age, grade):
        if not student_id:
            self.view.show_error("Validation Error", "Student ID cannot be empty.")
            return False
        if not name:
            self.view.show_error("Validation Error", "Name cannot be empty.")
            return False
        if not age:
            self.view.show_error("Validation Error", "Age cannot be empty.")
            return False
        if not grade:
            self.view.show_error("Validation Error", "Grade cannot be empty.")
            return False

        try:
            age_value = int(age)
        except ValueError:
            self.view.show_error("Validation Error", "Age must be a number.")
            return False

        if age_value <= 0:
            self.view.show_error("Validation Error", "Age must be greater than 0.")
            return False

        return True

    def add_student(self):
        student_id, name, age, grade = self.view.get_form_data()

        if not self.validate_input(student_id, name, age, grade):
            return

        if self.manager.find_student(student_id):
            self.view.show_error("Duplicate ID", "This Student ID already exists.")
            return

        student = Student(student_id, name, int(age), grade)
        self.manager.add_student(student)

        self.refresh_table()
        self.clear_form()
        self.view.show_message("Success", "Student added successfully.")

    def update_student(self):
        student_id, name, age, grade = self.view.get_form_data()

        if not self.validate_input(student_id, name, age, grade):
            return

        updated = self.manager.update_student(student_id, name, int(age), grade)

        if not updated:
            self.view.show_error("Not Found", "Student ID not found.")
            return

        self.refresh_table()
        self.clear_form()
        self.view.show_message("Success", "Student updated successfully.")

    def delete_student(self):
        student_id, name, age, grade = self.view.get_form_data()

        if not student_id:
            self.view.show_error("Validation Error", "Select a student to delete.")
            return

        confirmed = self.view.ask_confirmation(
            "Confirm Delete",
            "Delete student " + student_id + "?"
        )

        if not confirmed:
            return

        deleted = self.manager.delete_student(student_id)

        if not deleted:
            self.view.show_error("Not Found", "Student ID not found.")
            return

        self.refresh_table()
        self.clear_form()
        self.view.show_message("Success", "Student deleted successfully.")

    def clear_form(self):
        self.view.clear_form()

    def select_student(self, event):
        selected = self.view.get_selected_item()

        if not selected:
            return

        values = self.view.get_row_values(selected[0])
        self.view.fill_form(*values)

    def search_student(self):
        keyword = self.view.entry_search.get().strip().lower()

        self.view.clear_table()

        for student in self.manager.get_all_students():
            if keyword in student.name.lower():
                self.view.insert_row(*student.get_info())

    def clear_search(self):
        self.view.entry_search.delete(0, "end")
        self.refresh_table()

    def refresh_table(self):
        self.view.clear_table()
        for student in self.manager.get_all_students():
            self.view.insert_row(*student.get_info())
