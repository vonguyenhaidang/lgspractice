import tkinter as tk

from views.student_view import StudentView
from controllers.student_controller import StudentController


def main():
    root = tk.Tk()
    view = StudentView(root)
    controller = StudentController(view)
    root.mainloop()


if __name__ == "__main__":
    main()
