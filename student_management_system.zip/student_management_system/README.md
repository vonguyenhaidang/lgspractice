# Student Management System (Python · Tkinter · OOP · MVC)

A desktop Student Management System built with Tkinter, structured using the
Model-View-Controller (MVC) pattern.

## Project structure

```
student_management_system/
├── main.py
├── models/
│   ├── __init__.py
│   ├── student.py          # One Student object's data and behavior
│   └── student_manager.py  # The full list of students + CRUD operations
├── views/
│   ├── __init__.py
│   └── student_view.py     # All Tkinter widgets (window, form, buttons, table)
└── controllers/
    ├── __init__.py
    └── student_controller.py  # Wires buttons to actions, validates, updates the view
```

## Requirements

- Python 3.8+
- Tkinter (included with standard Python on Windows/macOS; on Linux you may
  need `sudo apt install python3-tk`)

No third-party packages are required.

## Running it

From the `student_management_system` folder:

```bash
python main.py
```

The app opens with three sample students already loaded (S001–S003).

## Features

- **Add** a student (ID, Name, Age, Grade) with validation (no empty fields,
  age must be a positive number, no duplicate IDs)
- **Update** a student by selecting a row in the table, editing the form, and
  clicking Update
- **Delete** a student, with a confirmation prompt
- **Search** students by partial name match, and clear the search to restore
  the full list
- **Clear** the form manually at any time

## Why MVC?

- `models/` never imports `tkinter` — it knows nothing about buttons or windows.
- `views/student_view.py` only builds and exposes widgets — it contains no
  business logic (no validation, no data storage).
- `controllers/student_controller.py` is the only place that talks to both
  sides: it reads from the view, validates, calls the model, and refreshes
  the view.
- `main.py` just wires the three pieces together and starts the event loop.

This keeps each file small, testable, and easy to change independently —
e.g. you could swap Tkinter for a web UI by only rewriting `views/`.
