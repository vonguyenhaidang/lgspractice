class Student:

    def __init__(self, student_id, name, age, grade):
        self.student_id = student_id
        self.name = name
        self.age = age
        self.grade = grade

    def get_info(self):
        return (self.student_id, self.name, self.age, self.grade)

    def update(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

    def is_adult(self):
        return self.age >= 18
